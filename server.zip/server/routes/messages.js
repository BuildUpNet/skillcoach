import { Router } from "express";
import { pool } from "../db.js";

export const messagesRouter = Router();

const PAGE_SIZE = 20;

/* ---------- helpers ---------- */

async function getUnreadCount(userId) {
  const [rows] = await pool.query(
    `SELECT COUNT(*) AS c
       FROM engine4_messages_recipients r
      WHERE r.user_id = ?
        AND r.inbox_deleted = 0
        AND r.view_date IS NULL`,
    [userId]
  );
  return rows[0]?.c || 0;
}

async function otherRecipientNames(conversationId, viewerId) {
  const [rows] = await pool.query(
    `SELECT u.user_id, u.username, u.display_name
       FROM engine4_messages_recipients r
       JOIN engine4_users u ON u.user_id = r.user_id
      WHERE r.conversation_id = ? AND r.user_id != ?`,
    [conversationId, viewerId]
  );
  return rows;
}

/* ---------- inbox ---------- */

messagesRouter.get("/inbox", async (req, res) => {
  try {
    const viewerId = req.userId;
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const offset = (page - 1) * PAGE_SIZE;

    const [[{ total }]] = await pool.query(
      `SELECT COUNT(*) AS total
         FROM engine4_messages_recipients r
        WHERE r.user_id = ? AND r.inbox_deleted = 0`,
      [viewerId]
    );

    const [convos] = await pool.query(
      `SELECT c.conversation_id, c.subject, c.locked, c.modified_date,
              r.view_date, r.last_message_id
         FROM engine4_messages_recipients r
         JOIN engine4_messages_conversations c ON c.conversation_id = r.conversation_id
        WHERE r.user_id = ? AND r.inbox_deleted = 0
        ORDER BY c.modified_date DESC
        LIMIT ? OFFSET ?`,
      [viewerId, PAGE_SIZE, offset]
    );

    const withMeta = await Promise.all(
      convos.map(async (c) => {
        const others = await otherRecipientNames(c.conversation_id, viewerId);
        const [[last]] = await pool.query(
          `SELECT body, owner_id, creation_date
             FROM engine4_messages_messages
            WHERE conversation_id = ?
            ORDER BY message_id DESC LIMIT 1`,
          [c.conversation_id]
        );
        return {
          id: c.conversation_id,
          subject: c.subject,
          locked: !!c.locked,
          unread: !c.view_date,
          from: others.map((o) => o.display_name || o.username).join(", "),
          preview: last?.body?.slice(0, 140) || "",
          time: c.modified_date,
        };
      })
    );

    res.json({
      conversations: withMeta,
      page,
      pageSize: PAGE_SIZE,
      total,
      pages: Math.ceil(total / PAGE_SIZE),
      unread: await getUnreadCount(viewerId),
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Couldn't load inbox." });
  }
});

/* ---------- outbox ---------- */

messagesRouter.get("/outbox", async (req, res) => {
  try {
    const viewerId = req.userId;
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const offset = (page - 1) * PAGE_SIZE;

    const [[{ total }]] = await pool.query(
      `SELECT COUNT(*) AS total
         FROM engine4_messages_recipients r
        WHERE r.user_id = ? AND r.outbox_deleted = 0`,
      [viewerId]
    );

    const [convos] = await pool.query(
      `SELECT c.conversation_id, c.subject, c.locked, c.modified_date
         FROM engine4_messages_recipients r
         JOIN engine4_messages_conversations c ON c.conversation_id = r.conversation_id
        WHERE r.user_id = ? AND r.outbox_deleted = 0
        ORDER BY c.modified_date DESC
        LIMIT ? OFFSET ?`,
      [viewerId, PAGE_SIZE, offset]
    );

    const withMeta = await Promise.all(
      convos.map(async (c) => {
        const others = await otherRecipientNames(c.conversation_id, viewerId);
        return {
          id: c.conversation_id,
          subject: c.subject,
          to: others.map((o) => o.display_name || o.username).join(", "),
          time: c.modified_date,
        };
      })
    );

    res.json({ conversations: withMeta, page, pageSize: PAGE_SIZE, total, pages: Math.ceil(total / PAGE_SIZE) });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Couldn't load outbox." });
  }
});

/* ---------- view a conversation thread ---------- */

messagesRouter.get("/conversation/:id", async (req, res) => {
  const viewerId = req.userId;
  const { id } = req.params;
  const conn = await pool.getConnection();
  try {
    const [[recipientRow]] = await conn.query(
      `SELECT * FROM engine4_messages_recipients WHERE conversation_id = ? AND user_id = ?`,
      [id, viewerId]
    );
    if (!recipientRow) return res.status(403).json({ error: "Not part of this conversation." });

    const [[convo]] = await conn.query(
      `SELECT * FROM engine4_messages_conversations WHERE conversation_id = ?`,
      [id]
    );
    if (!convo) return res.status(404).json({ error: "Conversation not found." });

    const [messages] = await conn.query(
      `SELECT m.message_id, m.owner_id, m.body, m.creation_date,
              u.username, u.display_name
         FROM engine4_messages_messages m
         JOIN engine4_users u ON u.user_id = m.owner_id
        WHERE m.conversation_id = ?
        ORDER BY m.message_id ASC`,
      [id]
    );

    const recipients = await otherRecipientNames(id, viewerId);

    await conn.query(
      `UPDATE engine4_messages_recipients SET view_date = NOW() WHERE conversation_id = ? AND user_id = ?`,
      [id, viewerId]
    );

    res.json({
      id: convo.conversation_id,
      subject: convo.subject,
      locked: !!convo.locked,
      recipients,
      messages: messages.map((m) => ({
        id: m.message_id,
        body: m.body,
        time: m.creation_date,
        from: { id: m.owner_id, name: m.display_name || m.username },
        self: m.owner_id === viewerId,
      })),
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Couldn't load conversation." });
  } finally {
    conn.release();
  }
});

/* ---------- reply ---------- */

messagesRouter.post("/conversation/:id/reply", async (req, res) => {
  const viewerId = req.userId;
  const { id } = req.params;
  const { body } = req.body;
  if (!body?.trim()) return res.status(400).json({ error: "Message can't be empty." });

  const conn = await pool.getConnection();
  try {
    const [[convo]] = await conn.query(
      `SELECT * FROM engine4_messages_conversations WHERE conversation_id = ?`,
      [id]
    );
    if (!convo) return res.status(404).json({ error: "Conversation not found." });
    if (convo.locked) return res.status(403).json({ error: "This conversation is locked." });

    const [[recipientRow]] = await conn.query(
      `SELECT 1 FROM engine4_messages_recipients WHERE conversation_id = ? AND user_id = ?`,
      [id, viewerId]
    );
    if (!recipientRow) return res.status(403).json({ error: "Not part of this conversation." });

    await conn.beginTransaction();

    await conn.query(
      `INSERT INTO engine4_messages_messages (conversation_id, owner_id, body, creation_date)
       VALUES (?, ?, ?, NOW())`,
      [id, viewerId, body.trim()]
    );

    await conn.query(
      `UPDATE engine4_messages_conversations
          SET modified_date = NOW(), message_count = message_count + 1
        WHERE conversation_id = ?`,
      [id]
    );

    await conn.query(
      `UPDATE engine4_messages_recipients
          SET view_date = NOW(), inbox_deleted = 0, outbox_deleted = 0
        WHERE conversation_id = ? AND user_id = ?`,
      [id, viewerId]
    );
    await conn.query(
      `UPDATE engine4_messages_recipients
          SET view_date = NULL, inbox_deleted = 0
        WHERE conversation_id = ? AND user_id != ?`,
      [id, viewerId]
    );

    await conn.commit();
    res.json({ ok: true });
  } catch (e) {
    await conn.rollback();
    console.error(e);
    res.status(500).json({ error: "Couldn't send reply." });
  } finally {
    conn.release();
  }
});

/* ---------- compose (new conversation) ---------- */

messagesRouter.post("/compose", async (req, res) => {
  const viewerId = req.userId;
  const { to, subject, body } = req.body;
  if (!subject?.trim() || !body?.trim()) {
    return res.status(400).json({ error: "Subject and message are required." });
  }

  let recipientIds = Array.isArray(to) ? to : String(to || "").split(",").map((s) => s.trim());
  recipientIds = [...new Set(recipientIds.filter(Boolean))].slice(0, 10);
  if (recipientIds.length === 0) {
    return res.status(400).json({ error: "Add at least one recipient." });
  }

  const conn = await pool.getConnection();
  try {
    const [users] = await conn.query(
      `SELECT user_id, username FROM engine4_users WHERE user_id IN (?) OR username IN (?)`,
      [recipientIds, recipientIds]
    );
    if (users.length === 0) return res.status(400).json({ error: "No valid recipients found." });

    const [[setting]] = await conn.query(
      `SELECT value FROM engine4_core_settings WHERE name = 'messages.auth' LIMIT 1`
    );
    if (setting?.value === "friends") {
      const [friends] = await conn.query(
        `SELECT resource_id AS friend_id
           FROM engine4_user_membership
          WHERE user_id = ? AND approved = 1
          UNION
         SELECT user_id AS friend_id
           FROM engine4_user_membership
          WHERE resource_id = ? AND approved = 1`,
        [viewerId, viewerId]
      );
      const friendIds = new Set(friends.map((f) => f.friend_id));
      const notFriend = users.find((u) => !friendIds.has(u.user_id));
      if (notFriend) {
        return res.status(403).json({ error: `${notFriend.username} is not in your friends list.` });
      }
    }

    await conn.beginTransaction();

    const [convoResult] = await conn.query(
      `INSERT INTO engine4_messages_conversations (subject, owner_id, locked, message_count, modified_date)
       VALUES (?, ?, 0, 1, NOW())`,
      [subject.trim(), viewerId]
    );
    const conversationId = convoResult.insertId;

    await conn.query(
      `INSERT INTO engine4_messages_messages (conversation_id, owner_id, body, creation_date)
       VALUES (?, ?, ?, NOW())`,
      [conversationId, viewerId, body.trim()]
    );

    const allRecipientIds = [...new Set([...users.map((u) => u.user_id), viewerId])];
    for (const uid of allRecipientIds) {
      await conn.query(
        `INSERT INTO engine4_messages_recipients
           (conversation_id, user_id, inbox_deleted, outbox_deleted, view_date, sent_date)
         VALUES (?, ?, 0, 0, ?, NOW())`,
        [conversationId, uid, uid === viewerId ? new Date() : null]
      );
    }

    await conn.commit();
    res.json({ ok: true, conversationId });
  } catch (e) {
    await conn.rollback();
    console.error(e);
    res.status(500).json({ error: "Couldn't send message." });
  } finally {
    conn.release();
  }
});

/* ---------- delete (soft) ---------- */

messagesRouter.post("/delete", async (req, res) => {
  const viewerId = req.userId;
  const { conversationIds, place } = req.body;
  if (!Array.isArray(conversationIds) || conversationIds.length === 0) {
    return res.status(400).json({ error: "No conversations selected." });
  }
  try {
    const column = place === "outbox" ? "outbox_deleted" : "inbox_deleted";
    await pool.query(
      `UPDATE engine4_messages_recipients
          SET ${column} = 1
        WHERE user_id = ? AND conversation_id IN (?)`,
      [viewerId, conversationIds]
    );
    res.json({ ok: true });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Couldn't delete." });
  }
});

/* ---------- search ---------- */

messagesRouter.get("/search", async (req, res) => {
  const viewerId = req.userId;
  const q = `%${req.query.query || ""}%`;
  try {
    const [rows] = await pool.query(
      `SELECT DISTINCT c.conversation_id, c.subject, c.modified_date
         FROM engine4_messages_messages m
         JOIN engine4_messages_conversations c ON c.conversation_id = m.conversation_id
         JOIN engine4_messages_recipients r ON r.conversation_id = c.conversation_id
        WHERE r.user_id = ? AND (c.subject LIKE ? OR m.body LIKE ?)
        ORDER BY c.modified_date DESC`,
      [viewerId, q, q]
    );
    res.json({ results: rows });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Search failed." });
  }
});